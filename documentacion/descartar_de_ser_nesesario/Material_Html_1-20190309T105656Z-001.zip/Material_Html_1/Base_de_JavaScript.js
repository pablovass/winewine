"use strict"
/* definicion de variables */
let nombreDeVariable = 2

/* definicion de variables */
const nobreDeConstante = "valor"

/* Defición de funciones */
/*son lo mismo*/
function miFuncion (){
    console.log("soy una funcion")
}

const miFuncion = function  (){
    console.log("soy una funcion")
}

const miFuncion = () => {
    console.log("soy una funcion")
}

/* por que tiene una sola linea */
const miFuncion = () => console.log("soy una funcion")

/* Invocar la funcion */
miFuncion()