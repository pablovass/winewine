declare 
 v_mensaje varchar2(100):= 'hola como estas mundo';
begin 
  DBMS_OUTPUT.PUT_line(v_mensaje);
  v_mensaje:='este es otro mensaja acinado a la misma variable ';
  DBMS_OUTPUT.PUT_line(v_mensaje);
end; 
/

declare
 vid_empleado EMPLOYEES.EMPLOYEE_ID%TYPE;

begin 
   if (vid_empleado is null) then 
    DBMS_OUTPUT.PUT_line(' empleado es null');
  else 
  DBMS_OUTPUT.PUT_line('empleado id '|| vid_empleado);
  end if;
end; 
/
declare
    v_cont number :=0;
begin 
    while (v_cont <10) 
    loop 
    dbms_output.put_line('valor: '|| v_cont);
    v_cont:= v_cont+1;
    end loop;
    
end ;
/
declare
      v_empleado EMPLOYEES.EMPLOYEE_ID%TYPE:= 100;
      v_salario EMPLOYEES.SALARY%TYPE;
begin 
      SELECT salary
      INTO v_salario
      FROM EMPLOYEES
      where EMPLOYEE_ID= v_empleado;
      
      DBMS_OUTPUT.put_line('ID DE EMPLEADO '|| v_empleado);
      DBMS_OUTPUT.put_line('SALARIO ' || v_salario);
end; 

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             