declare 
  v_empleadoCont  EMPLOYEES.EMPLOYEE_ID%TYPE:= '30';
begin 
   DBMS_OUTPUT.PUT_line('inicia el loop'); 
   LOOP
       IF (EMPLOYEE_ID < 50 )THEN
         DBMS_OUTPUT.PUT_LINE('empleados  ' || || ' is ' || 1/i);
       ELSE
         DBMS_OUTPUT.PUT_LINE('Reciprocal of ' || i || ' is ' || 1/i);
       END IF;
    
       i := i - 1;
     END LOOP;
   
end ;
